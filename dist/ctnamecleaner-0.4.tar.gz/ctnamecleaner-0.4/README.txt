# CT Name Cleaner

Resolve village and coloquial Connecticut town names, as well as common
misspellings of Connecticut town names to their official town names.

This is based on an R package of the same name by my colleague Andrew Ba Tran.

This installs a command line script, ctclean,  as well as a library 

by Jake Kara, jake@jakekara.com


